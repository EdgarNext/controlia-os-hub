import {
  KitchenActionRowSkeleton,
  KitchenCardGridSkeleton,
  KitchenTableSkeleton,
} from "./_components/kitchen-loading-skeletons";

export default function KitchenLoading() {
  return (
    <div className="space-y-4" aria-live="polite" aria-busy="true">
      <KitchenCardGridSkeleton cards={3} />
      <KitchenActionRowSkeleton actions={3} />
      <KitchenTableSkeleton rows={5} columns={5} />
    </div>
  );
}
